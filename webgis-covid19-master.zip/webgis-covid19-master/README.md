# WEBGIS COVID-19
Aplikasi GIS berbasis web standar yang dapat dikembangkan menjadi aplikasi yang lebih bermanfaat kedepannya.

# Komponen 
1. Menggunakan Bahasa Pemrogramman HTML, CSS dan Javascript (JQuery).
2. Tampilan Peta Menggunakan [Esri Leaflet](https://esri.github.io/esri-leaflet/) dan [Leaflet](https://leafletjs.com/).
3. Custom Dashboard Dari [Fulcrumapp](https://github.com/fulcrumapp).

# Developer
Berminat mengembangkan aplikasi ini? Silahkan hubungi:<br>
__Whatsapp :__ [085360989901](https://api.whatsapp.com/send?phone=6285360989901).

# Donasi
Jika dirasa Coding yang saya share bermanfaat, tidak ada salahnya bagi kalian jika ingin berdonasi. Untuk donasi kalian bisa melalui : <br>
__BANK BCA__\
__No. Rekening 7391181776__\
__An. MUHAMMAD IQBAL__ <br>
Berapapun Donasi Anda, Saya ucapkan Terima kasih banyak :)


Copyright © 2020 [Ibank.production](https://www.instagram.com/ibank.production/).<br>
All rights reserved.

